import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { Subject, Observable } from 'rxjs';
import { Chart } from "chart.js";
import { trigger, style, animate, transition } from '@angular/animations';
import { ChangeDetectorRef } from '@angular/core'
import * as moment from 'moment-timezone';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  animations: [
    trigger(
      'enterAnimation', [
      transition(':enter', [
        style({ transform: 'translateX(100%)', opacity: 0 }),
        animate('500ms', style({ transform: 'translateX(0)', opacity: 1 }))
      ]),
      transition(':leave', [
        style({ transform: 'translateX(0)', opacity: 1 }),
        animate('500ms', style({ transform: 'translateX(100%)', opacity: 0 }))
      ])
    ]
    )
  ],
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  // @ViewChild("lineCanvas", { static: true }) lineCanvas: ElementRef;
  // @ViewChild("doughnutCanvas", { static: true }) doughnutCanvas: ElementRef;
  // @ViewChild("barCanvas", { static: true }) barCanvas: ElementRef;
  // private barChart: Chart;
  // private lineChart: Chart;
  // private doughnutChart: Chart;


  public firstList = false;
  public secondList = false;
  public myDate = new Date().toISOString();
  public labelsList = [];
  public valuesList = [];
  public valuesList1 = [];
  public valuesList2 = [];
  constructor(private changeRef: ChangeDetectorRef) {

  }

  toggleList(tabNum) {
    switch (tabNum) {
      case 1: {
        this.firstList = !this.firstList;
        break;
      }
      case 2: {
        this.secondList = !this.secondList;
        break;
      }
    }
  }
  ngOnInit() {
    this.labelsList = ["8:00 AM", "8:30 AM", "8:45 AM", "10:00 AM", "12:00 PM", "12:30 PM"];
    this.valuesList = [250, 450, 1000, 500, 200, 300];
    this.valuesList1 = [120, 100, 130, 111, 23, 20];
    this.valuesList2 = [68,70,81,120,85,72];

    // this.doughnutChart = new Chart(this.doughnutCanvas.nativeElement, {
    //   type: "doughnut",
    //   data: {
    //     labels: ["Junk Food", "Dairy", "Meat", "Fruits & Vegetables", "Grains/Protiens"],
    //     datasets: [
    //       {
    //         label: "# of Votes",
    //         data: [12, 25, 30, 10, 20, 3],
    //         backgroundColor: [
    //           "rgba(255, 99, 132, 0.8)",
    //           "rgba(54, 162, 235, 0.8)",
    //           "rgba(255, 206, 86, 0.8)",
    //           "rgba(75, 192, 192, 0.8)",
    //           "rgba(153, 102, 255, 0.8)"
    //         ],
    //         borderWidth: 1
    //       }
    //     ]
    //   },
    //   options: {

    //   }
    // });
    // this.barChart = new Chart(this.barCanvas.nativeElement, {
    //   type: "bar",
    //   data: {
    //     labels: ["Temperate", "heart rate", "oxygen level", "Blood pressure", "blood sugar"],
    //     datasets: [
    //       {
    //         label: "Body parameters(Avg.)",
    //         data: [12, 19, 3, 5, 2],
    //         backgroundColor: [
    //           "rgba(255, 99, 132, 0.2)",
    //           "rgba(54, 162, 235, 0.2)",
    //           "rgba(255, 206, 86, 0.2)",
    //           "rgba(75, 192, 192, 0.2)",
    //           "rgba(153, 102, 255, 0.2)",
    //           "rgba(255, 159, 64, 0.2)"
    //         ],
    //         borderColor: [
    //           "rgba(255,99,132,1)",
    //           "rgba(54, 162, 235, 1)",
    //           "rgba(255, 206, 86, 1)",
    //           "rgba(75, 192, 192, 1)",
    //           "rgba(153, 102, 255, 1)",
    //           "rgba(255, 159, 64, 1)"
    //         ],
    //         borderWidth: 1
    //       }
    //     ],

    //   },
    //   options: {
    //     scales: {
    //       yAxes: [
    //         {
    //           ticks: {
    //             beginAtZero: false
    //           }
    //         }
    //       ]
    //     }
    //   }
    // });
    // this.lineChart = new Chart(this.lineCanvas.nativeElement, {
    //   type: "line",
    //   data: {
    //     labels: this.labelsList,
    //     datasets: [
    //       {
    //         label: "Pulse Rate",
    //         data: this.valuesList2,
    //         backgroundColor: [
    //           "rgba(255, 99, 132, 0.2)",
    //         ],
    //         borderColor: [
    //           "rgba(255,99,132,1)",
    //         ],
    //         borderWidth: 1
    //       }
    //     ]
    //   },
    //   options: {
    //     scales: {
    //       yAxes: [
    //         {
    //           ticks: {
    //             beginAtZero: false
    //           }
    //         }
    //       ]
    //     }
    //   }
    // });
  }

}
